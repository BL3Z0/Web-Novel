"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Trash2, HardDrive } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface CachedStory {
  id: string
  title: string
  size: number
  cachedAt: string
}

export function StoryCacheManager() {
  const [cachedStories, setCachedStories] = useState<CachedStory[]>([])
  const [cacheSize, setCacheSize] = useState(0)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadCachedStories()
  }, [])

  const loadCachedStories = async () => {
    try {
      if ("caches" in window) {
        const cache = await caches.open("dynamic-v1")
        const requests = await cache.keys()

        const stories: CachedStory[] = []
        let totalSize = 0

        for (const request of requests) {
          if (request.url.includes("/story/")) {
            const response = await cache.match(request)
            if (response) {
              const size = Number.parseInt(response.headers.get("content-length") || "0")
              const storyId = request.url.split("/story/")[1]

              stories.push({
                id: storyId,
                title: `Story ${storyId}`,
                size,
                cachedAt: new Date().toISOString(),
              })
              totalSize += size
            }
          }
        }

        setCachedStories(stories)
        setCacheSize(totalSize)
      }
    } catch (error) {
      console.error("Failed to load cached stories:", error)
    }
  }

  const cacheStory = async (storyId: string) => {
    setIsLoading(true)
    try {
      // Pre-cache the story by fetching it
      const response = await fetch(`/story/${storyId}`)
      if (response.ok) {
        toast({
          title: "Story cached",
          description: "Story is now available offline",
        })
        loadCachedStories()
      }
    } catch (error) {
      toast({
        title: "Cache failed",
        description: "Failed to cache story for offline reading",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const removeCachedStory = async (storyId: string) => {
    try {
      if ("caches" in window) {
        const cache = await caches.open("dynamic-v1")
        const requests = await cache.keys()

        for (const request of requests) {
          if (request.url.includes(`/story/${storyId}`)) {
            await cache.delete(request)
          }
        }

        toast({
          title: "Story removed",
          description: "Story removed from offline storage",
        })
        loadCachedStories()
      }
    } catch (error) {
      toast({
        title: "Remove failed",
        description: "Failed to remove story from cache",
        variant: "destructive",
      })
    }
  }

  const clearAllCache = async () => {
    try {
      if ("caches" in window) {
        await caches.delete("dynamic-v1")
        toast({
          title: "Cache cleared",
          description: "All offline stories have been removed",
        })
        loadCachedStories()
      }
    } catch (error) {
      toast({
        title: "Clear failed",
        description: "Failed to clear cache",
        variant: "destructive",
      })
    }
  }

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 B"
    const k = 1024
    const sizes = ["B", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <HardDrive className="mr-2 h-5 w-5" />
          Offline Storage
        </CardTitle>
        <CardDescription>Manage stories available for offline reading</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            {cachedStories.length} stories cached • {formatSize(cacheSize)} used
          </div>
          <Button variant="outline" size="sm" onClick={clearAllCache}>
            <Trash2 className="mr-2 h-4 w-4" />
            Clear All
          </Button>
        </div>

        {cachedStories.length > 0 && (
          <div className="space-y-2">
            {cachedStories.map((story) => (
              <div key={story.id} className="flex items-center justify-between p-2 border rounded">
                <div className="flex-1">
                  <div className="font-medium">{story.title}</div>
                  <div className="text-sm text-muted-foreground">
                    {formatSize(story.size)} • Cached {new Date(story.cachedAt).toLocaleDateString()}
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => removeCachedStory(story.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}

        {cachedStories.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">No stories cached for offline reading</div>
        )}
      </CardContent>
    </Card>
  )
}
