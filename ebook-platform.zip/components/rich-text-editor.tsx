"use client"

import type React from "react"

import { useState, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { AudioPlayer } from "@/components/audio-player"
import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Heading1,
  Heading2,
  Heading3,
  Quote,
  List,
  ListOrdered,
  ImageIcon,
  Music,
  Palette,
  Eye,
  Type,
  Upload,
  X,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface RichTextEditorProps {
  content: any
  onChange: (content: any) => void
  layoutStyle: string
  onLayoutChange: (layout: string) => void
  audioUrl?: string | null
  onAudioChange?: (audioUrl: string | null) => void
}

const layoutOptions = [
  { id: "default", name: "Classic", description: "Traditional book layout" },
  { id: "modern", name: "Modern", description: "Clean, minimalist design" },
  { id: "elegant", name: "Elegant", description: "Sophisticated typography" },
  { id: "magazine", name: "Magazine", description: "Multi-column layout" },
  { id: "journal", name: "Journal", description: "Personal diary style" },
]

export function RichTextEditor({
  content,
  onChange,
  layoutStyle,
  onLayoutChange,
  audioUrl,
  onAudioChange,
}: RichTextEditorProps) {
  const [activeFormats, setActiveFormats] = useState<Set<string>>(new Set())
  const [showLayoutPanel, setShowLayoutPanel] = useState(false)
  const [showAudioPanel, setShowAudioPanel] = useState(false)
  const [isUploadingAudio, setIsUploadingAudio] = useState(false)
  const audioInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const toggleFormat = useCallback(
    (format: string) => {
      const newFormats = new Set(activeFormats)
      if (newFormats.has(format)) {
        newFormats.delete(format)
      } else {
        newFormats.add(format)
      }
      setActiveFormats(newFormats)
    },
    [activeFormats],
  )

  const insertHeading = useCallback((level: number) => {
    // Implementation would insert heading at cursor position
    console.log(`[v0] Inserting heading level ${level}`)
  }, [])

  const insertQuote = useCallback(() => {
    console.log("[v0] Inserting quote block")
  }, [])

  const insertList = useCallback((ordered: boolean) => {
    console.log(`[v0] Inserting ${ordered ? "ordered" : "unordered"} list`)
  }, [])

  const handleAudioUpload = useCallback(
    async (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0]
      if (!file) return

      // Validate file type
      if (!file.type.startsWith("audio/")) {
        toast({
          title: "Invalid file type",
          description: "Please select an audio file (MP3, WAV, etc.)",
          variant: "destructive",
        })
        return
      }

      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Audio file must be less than 10MB",
          variant: "destructive",
        })
        return
      }

      setIsUploadingAudio(true)

      try {
        // Create a temporary URL for preview
        const tempUrl = URL.createObjectURL(file)
        onAudioChange?.(tempUrl)

        toast({
          title: "Audio uploaded",
          description: "Background audio has been added to your story",
        })
      } catch (error) {
        toast({
          title: "Upload failed",
          description: "Failed to upload audio file. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsUploadingAudio(false)
      }
    },
    [onAudioChange, toast],
  )

  const removeAudio = useCallback(() => {
    onAudioChange?.(null)
    if (audioInputRef.current) {
      audioInputRef.current.value = ""
    }
    toast({
      title: "Audio removed",
      description: "Background audio has been removed from your story",
    })
  }, [onAudioChange, toast])

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Story Editor</CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                variant={showLayoutPanel ? "default" : "outline"}
                size="sm"
                onClick={() => setShowLayoutPanel(!showLayoutPanel)}
              >
                <Palette className="mr-2 h-4 w-4" />
                Layout
              </Button>
              <Button
                variant={showAudioPanel ? "default" : "outline"}
                size="sm"
                onClick={() => setShowAudioPanel(!showAudioPanel)}
              >
                <Music className="mr-2 h-4 w-4" />
                Audio
              </Button>
              <Button variant="outline" size="sm">
                <Eye className="mr-2 h-4 w-4" />
                Preview
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Layout Selection Panel */}
          {showLayoutPanel && (
            <div className="p-4 bg-muted/50 rounded-lg space-y-3">
              <h4 className="font-medium flex items-center">
                <Type className="mr-2 h-4 w-4" />
                Choose Layout Style
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                {layoutOptions.map((layout) => (
                  <button
                    key={layout.id}
                    onClick={() => onLayoutChange(layout.id)}
                    className={cn(
                      "p-3 text-left border rounded-lg hover:bg-background transition-colors",
                      layoutStyle === layout.id ? "border-primary bg-primary/5" : "border-border",
                    )}
                  >
                    <div className="font-medium text-sm">{layout.name}</div>
                    <div className="text-xs text-muted-foreground mt-1">{layout.description}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Audio Upload Panel */}
          {showAudioPanel && (
            <div className="p-4 bg-muted/50 rounded-lg space-y-4">
              <h4 className="font-medium flex items-center">
                <Music className="mr-2 h-4 w-4" />
                Background Audio
              </h4>

              {!audioUrl ? (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Add background music or ambient sounds to enhance your story's atmosphere.
                  </p>
                  <div className="flex items-center space-x-2">
                    <Input
                      ref={audioInputRef}
                      type="file"
                      accept="audio/*"
                      onChange={handleAudioUpload}
                      disabled={isUploadingAudio}
                      className="hidden"
                      id="audio-upload"
                    />
                    <Label htmlFor="audio-upload" asChild>
                      <Button variant="outline" disabled={isUploadingAudio}>
                        <Upload className="mr-2 h-4 w-4" />
                        {isUploadingAudio ? "Uploading..." : "Upload Audio"}
                      </Button>
                    </Label>
                  </div>
                  <p className="text-xs text-muted-foreground">Supported formats: MP3, WAV, OGG. Max size: 10MB</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">Background Audio Added</p>
                    <Button variant="ghost" size="sm" onClick={removeAudio}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <AudioPlayer audioUrl={audioUrl} title="Story Background Audio" autoPlay={false} loop={true} />
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="audio-replace" asChild>
                      <Button variant="outline" size="sm" disabled={isUploadingAudio}>
                        <Upload className="mr-2 h-4 w-4" />
                        Replace Audio
                      </Button>
                    </Label>
                    <Input
                      id="audio-replace"
                      type="file"
                      accept="audio/*"
                      onChange={handleAudioUpload}
                      disabled={isUploadingAudio}
                      className="hidden"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Formatting Toolbar */}
          <div className="flex flex-wrap items-center gap-1">
            {/* Text Formatting */}
            <div className="flex items-center">
              <Button
                variant={activeFormats.has("bold") ? "default" : "ghost"}
                size="sm"
                onClick={() => toggleFormat("bold")}
              >
                <Bold className="h-4 w-4" />
              </Button>
              <Button
                variant={activeFormats.has("italic") ? "default" : "ghost"}
                size="sm"
                onClick={() => toggleFormat("italic")}
              >
                <Italic className="h-4 w-4" />
              </Button>
              <Button
                variant={activeFormats.has("underline") ? "default" : "ghost"}
                size="sm"
                onClick={() => toggleFormat("underline")}
              >
                <Underline className="h-4 w-4" />
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Headings */}
            <div className="flex items-center">
              <Button variant="ghost" size="sm" onClick={() => insertHeading(1)}>
                <Heading1 className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => insertHeading(2)}>
                <Heading2 className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => insertHeading(3)}>
                <Heading3 className="h-4 w-4" />
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Alignment */}
            <div className="flex items-center">
              <Button variant="ghost" size="sm">
                <AlignLeft className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <AlignCenter className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <AlignRight className="h-4 w-4" />
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Lists and Quotes */}
            <div className="flex items-center">
              <Button variant="ghost" size="sm" onClick={() => insertList(false)}>
                <List className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => insertList(true)}>
                <ListOrdered className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={insertQuote}>
                <Quote className="h-4 w-4" />
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Media */}
            <div className="flex items-center">
              <Button variant="ghost" size="sm">
                <ImageIcon className="h-4 w-4" />
              </Button>
              <Button
                variant={audioUrl ? "default" : "ghost"}
                size="sm"
                onClick={() => setShowAudioPanel(!showAudioPanel)}
              >
                <Music className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Current Layout Badge */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Current layout:</span>
              <Badge variant="outline">{layoutOptions.find((l) => l.id === layoutStyle)?.name || "Default"}</Badge>
              {audioUrl && (
                <Badge variant="secondary" className="ml-2">
                  <Music className="mr-1 h-3 w-3" />
                  Audio Added
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Editor Content Area */}
      <Card className="min-h-[600px]">
        <CardContent className="p-0">
          <div
            className={cn(
              "min-h-[600px] p-8 focus:outline-none",
              layoutStyle === "modern" && "font-sans leading-relaxed",
              layoutStyle === "elegant" && "font-serif leading-loose",
              layoutStyle === "magazine" && "columns-2 gap-8",
              layoutStyle === "journal" && "font-mono text-sm leading-relaxed",
            )}
            contentEditable
            suppressContentEditableWarning
            style={{
              background: layoutStyle === "journal" ? "#fefdf8" : "transparent",
            }}
          >
            <div className="prose prose-lg max-w-none">
              <h1 className="text-3xl font-bold mb-6">Your Story Title</h1>
              <p className="text-muted-foreground mb-8">
                Start writing your story here. Use the toolbar above to format your text, add headings, insert images,
                and choose different layout styles to make your story beautiful and engaging.
              </p>
              <p>
                This rich text editor supports multiple formatting options and layout styles. You can create immersive
                reading experiences with background audio, beautiful typography, and responsive layouts that work great
                on all devices.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
