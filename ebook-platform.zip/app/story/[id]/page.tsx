"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, BookOpen, Settings, Sun, Moon, Minus, Plus } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { AudioPlayer } from "@/components/audio-player"

interface Story {
  id: string
  title: string
  description: string
  content: any
  cover_image_url: string | null
  audio_url: string | null
  layout_style: string
  publisher_id: string
  profiles?: {
    full_name: string
  }
}

export default function StoryPage() {
  const params = useParams()
  const router = useRouter()
  const [story, setStory] = useState<Story | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [readingProgress, setReadingProgress] = useState(0)
  const [showSettings, setShowSettings] = useState(false)
  const [fontSize, setFontSize] = useState(16)
  const [isDarkMode, setIsDarkMode] = useState(false)

  useEffect(() => {
    loadStory()
  }, [params.id])

  const loadStory = async () => {
    const supabase = createClient()

    try {
      const { data, error } = await supabase
        .from("stories")
        .select(`
          *,
          profiles!stories_publisher_id_fkey(full_name)
        `)
        .eq("id", params.id)
        .eq("is_published", true)
        .single()

      if (error) throw error
      setStory(data)

      // Load reading progress
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (user) {
        const { data: progress } = await supabase
          .from("reading_progress")
          .select("progress_percentage")
          .eq("reader_id", user.id)
          .eq("story_id", params.id)
          .single()

        if (progress) {
          setReadingProgress(progress.progress_percentage)
        }
      }
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Failed to load story")
    } finally {
      setIsLoading(false)
    }
  }

  const updateProgress = async (progress: number) => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (user && story) {
      await supabase.from("reading_progress").upsert({
        reader_id: user.id,
        story_id: story.id,
        progress_percentage: progress,
        last_read_at: new Date().toISOString(),
      })
      setReadingProgress(progress)
    }
  }

  const handleScroll = () => {
    const scrollTop = window.scrollY
    const docHeight = document.documentElement.scrollHeight - window.innerHeight
    const scrollPercent = (scrollTop / docHeight) * 100

    if (scrollPercent > readingProgress) {
      updateProgress(Math.min(scrollPercent, 100))
    }
  }

  useEffect(() => {
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [readingProgress])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading story...</p>
        </div>
      </div>
    )
  }

  if (error || !story) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="text-center py-8">
            <BookOpen className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Story not found</h2>
            <p className="text-muted-foreground mb-4">{error || "This story may not be published yet."}</p>
            <Button asChild>
              <Link href="/reader/dashboard">Back to Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className={cn("min-h-screen transition-colors", isDarkMode ? "dark bg-slate-900" : "bg-background")}>
      {/* Reading Progress Bar */}
      <div className="fixed top-0 left-0 right-0 z-50">
        <Progress value={readingProgress} className="h-1 rounded-none" />
      </div>

      {/* Audio Player - Fixed Position */}
      {story.audio_url && (
        <div className="fixed bottom-4 right-4 z-50 w-80">
          <AudioPlayer
            audioUrl={story.audio_url}
            title={`${story.title} - Background Audio`}
            autoPlay={false}
            loop={true}
          />
        </div>
      )}

      {/* Header */}
      <div className="sticky top-1 z-40 bg-background/80 backdrop-blur-sm border-b">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/reader/dashboard">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back
                </Link>
              </Button>
              <div className="hidden md:block">
                <h1 className="font-medium line-clamp-1">{story.title}</h1>
                <p className="text-sm text-muted-foreground">by {story.profiles?.full_name || "Anonymous"}</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {story.audio_url && <AudioPlayer audioUrl={story.audio_url} compact={true} />}
              <Button variant="ghost" size="sm" onClick={() => setShowSettings(!showSettings)}>
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Reading Settings Panel */}
      {showSettings && (
        <div className="fixed top-16 right-4 z-40 w-64">
          <Card>
            <CardContent className="p-4 space-y-4">
              <h3 className="font-medium">Reading Settings</h3>

              <div className="space-y-2">
                <label className="text-sm font-medium">Font Size</label>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={() => setFontSize(Math.max(12, fontSize - 2))}>
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="text-sm w-8 text-center">{fontSize}px</span>
                  <Button variant="outline" size="sm" onClick={() => setFontSize(Math.min(24, fontSize + 2))}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Theme</label>
                <div className="flex items-center space-x-2">
                  <Button variant={!isDarkMode ? "default" : "outline"} size="sm" onClick={() => setIsDarkMode(false)}>
                    <Sun className="h-4 w-4" />
                  </Button>
                  <Button variant={isDarkMode ? "default" : "outline"} size="sm" onClick={() => setIsDarkMode(true)}>
                    <Moon className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Story Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Story Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4 text-balance">{story.title}</h1>
            <p className="text-xl text-muted-foreground mb-2">by {story.profiles?.full_name || "Anonymous"}</p>
            {story.description && (
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">{story.description}</p>
            )}
          </div>

          {/* Story Content */}
          <div
            className={cn(
              "prose prose-lg max-w-none transition-all",
              story.layout_style === "modern" && "font-sans leading-relaxed",
              story.layout_style === "elegant" && "font-serif leading-loose prose-headings:font-serif",
              story.layout_style === "magazine" && "columns-2 gap-8 prose-p:text-justify",
              story.layout_style === "journal" && "font-mono text-sm leading-relaxed bg-amber-50/50 p-8 rounded-lg",
              isDarkMode && "prose-invert",
            )}
            style={{
              fontSize: `${fontSize}px`,
              background: story.layout_style === "journal" && isDarkMode ? "#1f2937" : undefined,
            }}
          >
            <div className="space-y-6">
              <p className="text-lg leading-relaxed">
                Once upon a time, in a world not so different from our own, there lived a storyteller who understood the
                power of words. This storyteller knew that every tale had the ability to transport readers to distant
                lands, introduce them to fascinating characters, and teach them valuable lessons about life, love, and
                the human experience.
              </p>

              <p className="leading-relaxed">
                The art of storytelling has been with humanity since the dawn of civilization. From cave paintings to
                oral traditions, from written manuscripts to digital platforms, stories have always found a way to
                connect us across time and space. They remind us of our shared humanity and help us understand
                perspectives different from our own.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4">The Magic of Reading</h2>

              <p className="leading-relaxed">
                Reading is more than just decoding words on a page. It's an active process of imagination, empathy, and
                discovery. When we read, we become co-creators of the story, filling in details with our own experiences
                and emotions. Each reader brings something unique to the narrative, making every reading experience
                personal and meaningful.
              </p>

              <blockquote className="border-l-4 border-primary pl-6 italic text-lg my-8">
                "A reader lives a thousand lives before he dies. The man who never reads lives only one."
              </blockquote>

              <p className="leading-relaxed">
                In our digital age, the way we consume stories continues to evolve. Interactive elements, multimedia
                integration, and personalized reading experiences are reshaping how we engage with narratives. Yet the
                fundamental power of a well-told story remains unchanged.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4">Creating Immersive Experiences</h2>

              <p className="leading-relaxed">
                Modern ebook platforms offer unprecedented opportunities to create immersive reading experiences.
                Background audio can set the mood, custom layouts can enhance the visual appeal, and interactive
                elements can engage readers in new ways. These tools, when used thoughtfully, can elevate storytelling
                to new heights.
              </p>

              <p className="leading-relaxed">
                The key is to remember that technology should serve the story, not overshadow it. The best digital
                reading experiences are those that feel natural and intuitive, allowing readers to lose themselves in
                the narrative without being distracted by unnecessary bells and whistles.
              </p>

              <p className="leading-relaxed text-lg font-medium mt-12">
                And so our story continues, with each page turn bringing new discoveries, new emotions, and new
                connections between the reader and the tale being told...
              </p>
            </div>
          </div>

          {/* Story End */}
          <div className="text-center mt-16 py-8 border-t">
            <p className="text-muted-foreground mb-4">Thank you for reading!</p>
            <div className="flex items-center justify-center space-x-4">
              <Button asChild>
                <Link href="/reader/dashboard">More Stories</Link>
              </Button>
              <Button variant="outline">Share Story</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
